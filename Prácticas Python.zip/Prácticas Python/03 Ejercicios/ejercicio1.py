pais = "Guinea Ecuatorial"
continente = "Africa"
year = 2021

print(f"{pais} {continente} {year}")