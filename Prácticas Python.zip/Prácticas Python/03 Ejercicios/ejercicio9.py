
num = int(input("num: "))

while num != 111:
    num = int(input("num: "))
    print (num)
