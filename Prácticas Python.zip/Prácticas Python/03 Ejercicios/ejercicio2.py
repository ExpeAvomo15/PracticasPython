
contador = 1

while contador <=100:
    if contador%2 ==0:
        print(contador)
    contador+=1