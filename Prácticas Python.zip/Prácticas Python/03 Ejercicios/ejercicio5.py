num1 = int(input("num1: "))
num2 = int(input("num2: "))

if num1<num2:
    for num in range (num1, (num2+1)):
        print (num)

    


