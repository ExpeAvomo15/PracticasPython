num1 = int(input("num1: "))
num2 = int(input("num2: "))

if num1<num2:
    
    for X in range (num1, (num2+1)):
        if(X%2 !=0):
            print(X)






    

