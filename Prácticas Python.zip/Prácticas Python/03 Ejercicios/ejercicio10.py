contador=1
apr=0
susp=0

num_alumnos = int(input("Cuántos alumnos? "))

while contador <= num_alumnos:
    contador+=1
    nota=float(input("nota: "))
    if nota>=5:
        apr+=1
    elif nota <5:
        susp+=1

print(f"Aprobados {apr} Suspensos {susp} ")
