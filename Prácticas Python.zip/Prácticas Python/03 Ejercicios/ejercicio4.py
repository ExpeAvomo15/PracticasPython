#Operaciones Básicas

num1 = int(input("num1: "))
num2 = int(input("num2: "))

sum= num1+num2
res= num1-num2
mult = num1*num2
div = num1/num2
rest= num1%num2

print (f"suma: {sum}, resta: {res}, div: {div}, mult: {mult}, resto: {rest}")