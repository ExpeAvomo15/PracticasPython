total = int(input("num1: "))
num = int(input("num2: "))

per = total * (num*0.01)

print (per)
