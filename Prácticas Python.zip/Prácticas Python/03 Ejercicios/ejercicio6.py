#Mostrar todas las tablas de multiplicar del 1 al 10

for num1 in range (1, 11):
    print(f"Tabla del {num1} ")

    for num2 in range (1, 11):
        print (f"{num2} X {num1} = {num2*num1}")