
contador = 0
while contador<=60:
    cuadrado=contador*contador
    print(cuadrado)
    contador+=1