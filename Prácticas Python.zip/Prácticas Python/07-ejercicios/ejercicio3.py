"""
Hacer un programa que compruebe si una variable está vacía y si lo está 
que lo rellene con un exto en minusculas y al mostrarlo que sea en mayusculas

"""
texto = ""


if len(texto.strip()) <=0:
    #Mostra el texto
    texto_minusculas = "Hola soy Expe Avomo y soy elmayor experto en python, haré crecer tu empresa"
    texto=texto_minusculas
    print(texto.upper())

else:
    print("La variable tiene  contenido")
