"""
Escribir un programa que añada valores a una lista, mientras que su longitud sea menor a 120
y luego mostrar la lista.

Hacerlo con while y con for

"""

#Con For

coleccion = []

"""for contador in range(0,120):
    coleccion.append(f"elemento - {contador}")
    print(f"Mostrando el: " + coleccion[contador])
print (coleccion)"""

#Con While
X = 0
while X < 120:
    coleccion.append(f"elemento -  {X}")
    print(f"Mostrando el elemento: " + coleccion[X])
    X +=1

print(coleccion[110])
    
   
    


