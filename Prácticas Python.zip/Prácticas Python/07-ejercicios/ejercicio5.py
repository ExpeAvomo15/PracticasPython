"""
Crear una lista con el contenido de esta tabla:
ACCION    AVENTURA          DEPORTES
GTA       ASSINS               FIFA
          CRASH                PRO21
       Prince of Persia        MOTO GP 21
COD
PUGB

Mostrar esta información ordenada
"""

tabla = [
    {
        "categoria": "ACCION",
        "juegos": ["GTA", "COD", "PUGB"]
    },

    {
        "categoria": "AVENTURA",
        "juegos": ["FIFA", "PRO 21","MOTO GP 21"]
    },

    {
         "categoria": "DEPORTES",
        "juegos": ["ASSASINS", "CRASH","Prince of Persia"]
    }
]


for categoria in tabla:
    print(f"-------{categoria['categoria']}")
    for juego in categoria['juegos']:
        print(juego)    
