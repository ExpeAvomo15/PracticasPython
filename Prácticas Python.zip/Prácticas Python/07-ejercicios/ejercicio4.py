"""
Vamos a crear un script que tenga 4 variables: lista, string, int y booleana. El programa tendrá
que imprimir por pantalla, qué tipo de variable es cada una
"""


from xmlrpc.client import boolean


def tipado(dato,tipo):
    test = isinstance (dato, tipo)
    result=""

    if test:
        result = f"este dato es del tipo {type(dato)}"
    else:
        result = "El tipo no es correcto"
    
    return result

lista = ["Hola", 13]
texto = "hola que hace"
num = 12378
verdad = True

print(tipado(lista,list))
print(tipado(verdad,list))
print(tipado(num,int))
print(tipado(texto, boolean))