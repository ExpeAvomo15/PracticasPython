"""Un programa que tenga una lista de 8 numeros enteros y realice las siguienetes operaciones:
1. Recorrela y mostrarla
  -Hacer función  que  recorra lista de números y devuela String
2. ordenarla y mostrarla
3. Mostrar su longitud
4. buscar un elemento dentro de la lista
"""


"""
def mostrarLista(numeros):
    resultado = ""
    for numero in numeros:
        resultado += str(numero) + " "
        
    return resultado
    

lista_numeros = [20, 45, 60, 80, 1, 13, 26, 7]

print(mostrarLista(lista_numeros)) 

#Ordenar lista
lista_numeros.sort()
print(mostrarLista(lista_numeros))

#Mostrar longitud
print(len(lista_numeros))
try:
    #Buscar elemento
    busqueda = int(input("Introduce el némero: "))
    comprobar = isinstance(busqueda, int)
    while not comprobar or busqueda<=0:
        busqueda = int(input("Introduce el némero: "))
    else:
        print(f"Has introducido el numero {busqueda}")


    search = lista_numeros.index(busqueda)
    print(f"El número buscado existe en la lista. Es el índice {search}")
except:
    print("El número no está en la lista, lo siento")"""

    #Múltiples excepciones:
"""
try:

    numero = int(input("Numero para elevarlo al cuadrado: "))

    print("El cuadrado es: "+str(numero*numero))
except TypeError:
    print("Debes convertir  tus cadenas a enteros")
##except ValueError:
    print("Introduce un número correcto")
except Exception as e:
    print(type(e))
    print("Ha ocurrido un error: ", type(e).__name__)

"""

#Excepciones personalizadas o lanzar excepción
try:
    nombre = input("Introduce el nombre: ")
    edad = int (input("Introduce la edad: "))

    if edad<5 or edad>110:
        raise ValueError("La edada introducida no es real")
    elif len(nombre)<=1:
        raise ValueError("El error no está completo")
    else:
        print(f"Bienvenido al master en python {nombre}")
except ValueError:
    print("Introduce los datos correctamente")
except Exception as e:
    print("Existe un error: ", e)   





 


